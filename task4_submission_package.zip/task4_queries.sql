-- Task 4: SQL for Data Analysis
-- Dataset: Ecommerce_SQL_Database (sample)

-- 1. Select all users
SELECT * 
FROM users;

-- 2. Filter orders above 500 using WHERE
SELECT order_id, user_id, total_amount
FROM orders
WHERE total_amount > 500;

-- 3. Sort products by price in descending order
SELECT product_id, product_name, price
FROM products
ORDER BY price DESC;

-- 4. Group orders by user and calculate total spent
SELECT user_id, SUM(total_amount) AS total_spent
FROM orders
GROUP BY user_id;

-- 5. Average revenue per user
SELECT AVG(total_spent) AS avg_revenue_per_user
FROM (
    SELECT user_id, SUM(total_amount) AS total_spent
    FROM orders
    GROUP BY user_id
) AS sub;

-- 6. INNER JOIN users with their orders
SELECT u.user_id, u.username, o.order_id, o.total_amount
FROM users u
INNER JOIN orders o ON u.user_id = o.user_id
LIMIT 20;

-- 7. LEFT JOIN to include users with no orders
SELECT u.user_id, u.username, o.order_id, o.total_amount
FROM users u
LEFT JOIN orders o ON u.user_id = o.user_id
LIMIT 20;

-- 8. Subquery: Products with price greater than average price
SELECT product_id, product_name, price
FROM products
WHERE price > (SELECT AVG(price) FROM products);

-- 9. Create a view for top customers
CREATE VIEW IF NOT EXISTS top_customers AS
SELECT user_id, SUM(total_amount) AS total_spent
FROM orders
GROUP BY user_id
ORDER BY total_spent DESC;

-- 10. Optimize query using index
CREATE INDEX IF NOT EXISTS idx_orders_userid ON orders(user_id);