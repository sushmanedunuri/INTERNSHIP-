# Task 4: SQL for Data Analysis

## Objective
Practice SQL queries for data analysis on an ecommerce-style database.  
This repository contains SQL queries, sample data, and screenshots of query outputs.

## Files
- `task4_queries.sql` : SQL file with all queries used for the task.
- `ecommerce.db` : SQLite database containing sample tables (`users`, `products`, `orders`).
- `screenshots/` : PNG images and CSVs of query outputs (as required in deliverables).

## Tools Used
- SQLite (via Python `sqlite3`)
- Python (pandas, matplotlib) to run queries and capture outputs
- No paid tools were used.

## SQL Highlights
- Filtering with `WHERE`
- Ordering results with `ORDER BY`
- Aggregation with `GROUP BY`, `SUM`, `AVG`
- Joins: `INNER JOIN`, `LEFT JOIN`
- Subqueries
- Views (`top_customers`)
- Index creation for optimization (`idx_orders_userid`)

## How to reproduce locally
1. Clone the repository.
2. Open the `ecommerce.db` using SQLite Browser or connect with your preferred client.
3. Run `task4_queries.sql` in your SQL client, or run the provided Python script.

## Notes
- Sample data is synthetic and included to demonstrate query outputs.
- Screenshots mimic outputs from a SQL client and are saved in the `screenshots/` folder.